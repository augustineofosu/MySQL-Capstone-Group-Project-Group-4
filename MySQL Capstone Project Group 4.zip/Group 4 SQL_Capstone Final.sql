CREATE DATABASE Capstone;
USE Capstone;

-- creating people table --
CREATE TABLE People (person_id INT PRIMARY KEY AUTO_INCREMENT, name TEXT, gender TEXT, birthdate DATE, nationality TEXT, region TEXT, city TEXT, net_worth FLOAT);
INSERT INTO People (person_id, name, gender, birthdate, nationality, region, city, net_worth) VALUES
(1, 'Wizkid', 'Male', '1990-07-16', 'Nigerian', 'West Africa', 'Lagos', 300000000),
(2, 'Joe Mettle', 'Male', '1981-07-05', 'Ghanaian', 'West Africa', 'Accra',70000000),
(3, 'Beyonce', 'Female', '1981-09-04', 'American', 'North America', 'Texas',8000000),
(4, 'Van Vicker', 'Male', '1977-08-01', 'Ghanaian', 'West Africa', 'Accra',12000000),
(5, 'Jackie Appiah', 'Female', '1982-11-21', 'Ghanaian', 'West Africa', 'Accra',72000000),
(6, 'Dolly Parton', 'Female', '1946-01-19', 'American', 'North America', 'Texas',54000000),
(7, 'Miley Cyrus', 'Female', '1992-11-23', 'American', 'North America', 'Maryland',2000000),
(8, 'Common', 'Male', '1972-03-13', 'American', 'North America', 'Atlanta',30000000),
(9, 'Ramsey Noah', 'Male', '1987-04-15', 'Nigerian', 'West Africa', 'Abuja',25000000),
(10, 'Ed Sheeran', 'Male', '1991-02-17', 'British', 'Europe', 'London',14000000);

-- Creating movie table --
CREATE TABLE Movies (movie_id INT PRIMARY KEY AUTO_INCREMENT, person_id INT, title TEXT, release_year YEAR, genre TEXT, revenue FLOAT);
INSERT INTO Movies (movie_id, person_id, title, release_year, genre, revenue) VALUES
(1, 4, 'Heart Breakers Revenge', 2014, 'Drama', 7000000),
(2, 5, 'Red Carpet', 2009, 'Drama', 73000000),
(3, 6, 'Joyful Noise', 2012, 'Drama', 3000000),
(4, 6, 'Mountain Magic Christmas', 2022, 'Musical/Comedy', 15000000),
(5, 8, 'John Wick', 2014, 'Action', 12000000),
(6, 8, 'Breathe', 2024, 'Action', 12000000),
(7, 9, 'Figurine', 2019, 'Drama', 2000000),
(8, 9, 'Fisherman’s Diary', 2020, 'Drama', 4000000),
(9, 7, 'Drive Away Dolls', 2024, 'Comedy', 9000000),
(10, 7, 'Guardian of the Galaxy', 2017, 'Action', 22000000);

-- Creating music table --
CREATE TABLE Music (music_id INT PRIMARY KEY AUTO_INCREMENT, person_id INT, title TEXT, release_year YEAR, genre TEXT, revenue FLOAT);
INSERT INTO Music (music_id, person_id, title, release_year, genre, revenue) VALUES
(1, 3, 'Lemonade', 2016, 'Pop', 200000),
(2, 10, 'Perfect', 2017, 'Pop', 120000),
(3, 1, 'Brown Skin Girl', 2019, 'R&B', 2000000),
(4, 2, 'Sound of Praise', 2013, 'Gospel', 120000),
(5, 2, 'Onwanwani', 2016, 'Gospel', 70000),
(6, 6, 'Coat of Many Colors', 1971, 'Country', 21000),
(7, 10, 'Thinking Out Loud', 2014, 'Pop', 159000),
(8, 7, 'Flowers', 2023, 'Disco', 71000),
(9, 1, 'Essence', 2020, 'Afrobeat', 41000),
(10, 3, 'Halo', 2008, 'R&B', 320000);

-- Creating achievement table --
CREATE TABLE Achievement(achievement_id INT PRIMARY KEY AUTO_INCREMENT,person_id INT, achievement_name TEXT, category TEXT,year_won YEAR);
INSERT INTO Achievement(achievement_id, person_id, achievement_name, category, year_won) VALUES
(1, 1, 'Best Music Video', 'Grammy', 2021),
(2, 2, 'Male Artist of the Year', 'VGMA', 2020),
(3, 3, 'Best Album', 'Grammy', 2017),
(4, 4, 'Best Actor in a Supporting Role', 'Ghana Movies Award', 2020),
(5, 5, 'Best Actress in a Movie', 'AMVCA', 2018),
(6, 6, 'Best Song of the Year', 'Grammy', 2011),
(7, 7, 'Best Art Direction', 'MTV Europe Music Award', 2020),
(8, 8, 'Best Original Song', 'Academy Award', 2015),
(9, 9, 'Best Actor', 'AMVCA', 2010),
(10, 10, 'Song of the Year', 'Grammy', 2014);

-- Creating Occupation table --
CREATE TABLE Occupation (occupation_id INT PRIMARY KEY AUTO_INCREMENT, person_id INT, occupation TEXT, start_year YEAR, end_year YEAR DEFAULT NULL);
INSERT INTO Occupation (occupation_id, person_id, occupation, start_year, end_year) VALUES
(1, 1, 'Singer', 2010, NULL),
(2, 2, 'Singer', 2004, NULL),
(3, 3, 'Singer', 1998, NULL),
(4, 4, 'Actor', 2004, NULL),
(5, 5, 'Actor', 2004, NULL),
(6, 6, 'Singer, Actor', 1967, NULL),
(7, 7, 'Singer, Actor', 2006, NULL),
(8, 8, 'Actor', 1992, NULL),
(9, 9, 'Actor', 1993, NULL),
(10, 10, 'Singer', 2004, NULL);


SELECT * FROM People;
SELECT * FROM Movies;
SELECT * FROM Music;
SELECT * FROM Achievement;
SELECT * FROM Occupation;

-- Creating relationships --
SELECT * 
FROM People 
JOIN Movies 
ON People.person_id = Movies.person_id;

SELECT * 
FROM People 
JOIN Music 
ON People.person_id = Music.person_id;

SELECT * 
FROM People 
JOIN Achievement
ON People.person_id = Achievement.person_id;

-- Joining people and occupation --
SELECT * 
FROM People 
JOIN Occupation 
ON People.person_id = Occupation.person_id;

-- Joining movies and achievement --
SELECT * 
FROM Movies 
JOIN Achievement 
ON Movies.person_id = Achievement.person_id;

-- Joining music and achievement --
SELECT * 
FROM Music 
JOIN Achievement 
ON Music.person_id = Achievement.person_id;

-- Joining everything --
SELECT p.name, m.title AS movie_title, mu.title AS song_title, a.achievement_name, o.occupation
FROM People p
LEFT JOIN Movies m ON p.person_id = m.person_id
LEFT JOIN Music mu ON p.person_id = mu.person_id
LEFT JOIN Achievement a ON p.person_id = a.person_id
LEFT JOIN Occupation o ON p.person_id = o.person_id;


-- Bottom 3 Earners --
SELECT p.name, 
       COALESCE(SUM(m.revenue), 0) + COALESCE(SUM(mu.revenue), 0) AS total_revenue
FROM People p
LEFT JOIN Movies m ON p.person_id = m.person_id
LEFT JOIN Music mu ON p.person_id = mu.person_id
GROUP BY p.name
ORDER BY total_revenue ASC
LIMIT 3;

-- most profitable genre --
SELECT genre, SUM(revenue) AS total_revenue
FROM (
    SELECT genre, revenue FROM Movies
    UNION ALL
    SELECT genre, revenue FROM Music
) AS combined_data
GROUP BY genre
ORDER BY total_revenue DESC;

-- Country with most successful celebs --
SELECT p.nationality, COUNT(a.achievement_id) AS total_achievement
FROM People p
JOIN Achievement a ON p.person_id = a.person_id
GROUP BY p.nationality
ORDER BY total_achievement DESC;

-- wealth ranking --
SELECT p.name, p.nationality, p.net_worth,
    CASE 
        WHEN p.net_worth >= 200000000 THEN 'Elite'
        WHEN p.net_worth >= 71000000  THEN 'High'
        WHEN p.net_worth >= 30000000 THEN 'Medium'
        ELSE 'Low'
    END AS wealth_category
FROM People p
ORDER BY p.net_worth DESC;

-- 5 Least Successful People --
SELECT p.name, COALESCE(COUNT(a.achievement_id), 0) AS total_achievement
FROM People p
LEFT JOIN Achievement a ON p.person_id = a.person_id
GROUP BY p.name
ORDER BY total_achievement ASC
LIMIT 5;

-- Compare where they are from vs. where their movies/music make the most revenue --
SELECT p.nationality, p.region, 
       SUM(COALESCE(m.revenue, 0) + COALESCE(mu.revenue, 0)) AS total_revenue
FROM People p
LEFT JOIN Movies m ON p.person_id = m.person_id
LEFT JOIN Music mu ON p.person_id = mu.person_id
GROUP BY p.nationality, p.region
ORDER BY total_revenue DESC;


-- Counts how many awards exist in each category --
SELECT category, COUNT(achievement_id) AS total_achievement
FROM Achievement
GROUP BY category
ORDER BY total_achievement DESC;

 -- Types of achievements won the most -- 
SELECT category, COUNT(achievement_id) AS times_won
FROM Achievement
GROUP BY category
ORDER BY times_won DESC;

-- Gender distribution --
SELECT gender, COUNT(person_id) AS total_people
FROM People
GROUP BY gender;

USE capstone;
SELECT p.name, m.title AS movie_title, mu.title AS song_title, a.achievement_name, o.occupation
FROM People p
LEFT JOIN Movies m ON p.person_id = m.person_id
LEFT JOIN Music mu ON p.person_id = mu.person_id
LEFT JOIN Achievement a ON p.person_id = a.person_id
LEFT JOIN Occupation o ON p.person_id = o.person_id;

CREATE TABLE Fact_Entertainment (
    person_id INT PRIMARY KEY,
    name TEXT, gender TEXT, nationality TEXT,
    region TEXT,
    city TEXT,
    total_movies INT,
    total_movie_revenue FLOAT,
    total_songs INT,
    total_song_revenue FLOAT,
    total_achievement INT,
    achievement_categories TEXT,
    career_start_year YEAR,
    career_end_year YEAR,
    career_duration INT);
    
INSERT INTO Fact_Entertainment (
    person_id, name, gender, nationality, region, city,
    total_movies, total_movie_revenue, 
    total_songs, total_song_revenue, 
    total_achievement, achievement_categories,
    career_start_year, career_end_year, career_duration
)
SELECT 
    p.person_id, 
    p.name, 
    p.gender, 
    p.nationality,
    p.region,
    p.city,
    COALESCE(COUNT(DISTINCT m.movie_id), 0) AS total_movies,
    COALESCE(SUM(m.revenue), 0) AS total_movie_revenue,
    COALESCE(COUNT(DISTINCT mu.music_id), 0) AS total_songs,
    COALESCE(SUM(mu.revenue), 0) AS total_song_revenue,
    COALESCE(COUNT(DISTINCT a.achievement_id), 0) AS total_achievement,
    GROUP_CONCAT(DISTINCT a.category ORDER BY a.category SEPARATOR ', ') AS achievement_categories,
    MIN(o.start_year) AS career_start_year,
    COALESCE(MAX(o.end_year), YEAR(CURDATE())) AS career_end_year,
    (COALESCE(MAX(o.end_year), YEAR(CURDATE())) - MIN(o.start_year)) AS career_duration
FROM People p
LEFT JOIN Movies m ON p.person_id = m.person_id
LEFT JOIN Music mu ON p.person_id = mu.person_id
LEFT JOIN Achievement a ON p.person_id = a.person_id
LEFT JOIN Occupation o ON p.person_id = o.person_id
GROUP BY p.person_id, p.name, p.gender, p.nationality, p.region, p.city;
